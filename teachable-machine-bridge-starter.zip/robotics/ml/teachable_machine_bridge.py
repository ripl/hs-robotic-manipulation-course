import argparse
import json
import os
import sys
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse


BASE_DIR = Path(__file__).resolve().parents[2]
ML_DIR = Path(__file__).resolve().parent
DEFAULT_MAPPING_PATH = ML_DIR / "teachable_machine_actions.json"
DEFAULT_CONFIG_PATH = BASE_DIR / "robotics" / "config.json"
DEFAULT_ACTIONS_PATH = BASE_DIR / "robotics" / "actions.json"
POSE_SEQUENCE = ["hover", "pre-grasp", "grasp", "post-grasp"]


class ActionRunner:
    def __init__(self, mapping_path, config_path, actions_path, execute=False):
        self.mapping_path = Path(mapping_path)
        self.config_path = Path(config_path)
        self.actions_path = Path(actions_path)
        self.execute = execute
        self.mapping = self._load_json(self.mapping_path)
        self.robot = None
        self.arm_config = None
        self.actions = None

    def _load_json(self, path):
        with open(path) as f:
            return json.load(f)

    def _ensure_robot(self):
        if self.robot is not None:
            return

        sys.path.insert(0, str(BASE_DIR))
        from robotics.robot.robot import Robot

        config = self._load_json(self.config_path)
        self.arm_config = config["arm"]
        self.actions = self._load_json(self.actions_path)
        self.robot = Robot(
            device_name=self.arm_config["device_name"],
            baudrate=self.arm_config.get("baudrate", 1_000_000),
            servo_ids=self.arm_config["servo_ids"],
            velocity_limit=self.arm_config["velocity_limit"],
            max_position_limit=self.arm_config["max_position_limit"],
            min_position_limit=self.arm_config["min_position_limit"],
            position_p_gain=self.arm_config["position_p_gain"],
            position_i_gain=self.arm_config["position_i_gain"],
        )
        self.robot.set_and_wait_goal_pos(self.arm_config["home_pos"])

    def close(self):
        if self.robot is None:
            return
        try:
            if self.arm_config and "rest_pos" in self.arm_config:
                self.robot.set_and_wait_goal_pos(self.arm_config["rest_pos"])
            self.robot._disable_torque()
        finally:
            self.robot = None

    def _mapping_for_label(self, label):
        entry = self.mapping.get(label)
        if entry is None:
            return {"action": None, "reason": "No mapped action for class label."}
        if isinstance(entry, str):
            return {"action": entry}
        if isinstance(entry, dict):
            return entry
        return {"action": None, "reason": "Mapping entry must be a string, object, or null."}

    def run(self, label, probability):
        entry = self._mapping_for_label(label)
        action = entry.get("action")
        sequence = entry.get("sequence")

        if action is None and not sequence:
            return {
                "ok": True,
                "mode": "no_action",
                "label": label,
                "probability": probability,
                "reason": entry.get("reason") or entry.get("description") or "Class is mapped to no action.",
            }

        if not self.execute:
            return {
                "ok": True,
                "mode": "dry_run",
                "label": label,
                "probability": probability,
                "mapped": entry,
                "message": "Dry run only. Start bridge with --execute to move the robot.",
            }

        self._ensure_robot()
        if sequence:
            self._run_sequence(sequence)
        else:
            self._run_action(action)

        if self.arm_config and "home_pos" in self.arm_config:
            self.robot.set_and_wait_goal_pos(self.arm_config["home_pos"])

        return {
            "ok": True,
            "mode": "executed",
            "label": label,
            "probability": probability,
            "mapped": entry,
        }

    def _run_action(self, action_name):
        if action_name not in self.actions:
            raise ValueError(f'Action "{action_name}" is not in {self.actions_path}.')
        for pose in POSE_SEQUENCE:
            if pose not in self.actions[action_name]:
                raise ValueError(f'Action "{action_name}" is missing pose "{pose}".')
            self.robot.set_and_wait_goal_pos(self.actions[action_name][pose])
            time.sleep(0.25)

    def _run_sequence(self, sequence):
        for step in sequence:
            action_name = step["action"]
            pose = step["pose"]
            delay = float(step.get("delay", 0.25))
            if action_name not in self.actions:
                raise ValueError(f'Action "{action_name}" is not in {self.actions_path}.')
            if pose not in self.actions[action_name]:
                raise ValueError(f'Action "{action_name}" is missing pose "{pose}".')
            self.robot.set_and_wait_goal_pos(self.actions[action_name][pose])
            time.sleep(delay)


def make_handler(runner, args):
    class BridgeHandler(SimpleHTTPRequestHandler):
        def end_headers(self):
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            super().end_headers()

        def do_OPTIONS(self):
            self.send_response(204)
            self.end_headers()

        def do_GET(self):
            parsed = urlparse(self.path)
            if parsed.path == "/health":
                self._send_json({
                    "ok": True,
                    "execute": args.execute,
                    "mapping": str(args.mapping),
                    "actions": str(args.actions),
                })
                return
            if parsed.path in ["/", "/index.html"]:
                self._send_file(ML_DIR / "teachable_machine_demo.html", "text/html")
                return
            super().do_GET()

        def do_HEAD(self):
            parsed = urlparse(self.path)
            if parsed.path in ["/", "/index.html"]:
                self._send_file_headers(ML_DIR / "teachable_machine_demo.html", "text/html")
                return
            super().do_HEAD()

        def do_POST(self):
            parsed = urlparse(self.path)
            if parsed.path != "/prediction":
                self.send_error(404, "Unknown endpoint")
                return

            try:
                content_length = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
                label = payload["className"]
                probability = float(payload["probability"])
                result = runner.run(label, probability)
                self._send_json(result)
                print(f'[{result["mode"]}] {label} ({probability:.2f}) -> {result.get("mapped", result.get("reason"))}')
            except Exception as exc:
                self._send_json({"ok": False, "error": str(exc)}, status=400)
                print(f"[error] {exc}")

        def _send_json(self, data, status=200):
            body = json.dumps(data, indent=2).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _send_file(self, path, content_type):
            body = path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _send_file_headers(self, path, content_type):
            body_size = path.stat().st_size
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(body_size))
            self.end_headers()

    return BridgeHandler


def parse_args():
    parser = argparse.ArgumentParser(description="Local Teachable Machine to robot-action bridge.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--mapping", type=Path, default=DEFAULT_MAPPING_PATH)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG_PATH)
    parser.add_argument("--actions", type=Path, default=DEFAULT_ACTIONS_PATH)
    parser.add_argument("--execute", action="store_true", help="Physically move the robot. Off by default.")
    return parser.parse_args()


def main():
    args = parse_args()
    os.chdir(ML_DIR)
    runner = ActionRunner(args.mapping, args.config, args.actions, execute=args.execute)
    handler = make_handler(runner, args)
    server = ThreadingHTTPServer((args.host, args.port), handler)
    mode = "EXECUTE" if args.execute else "DRY RUN"
    print(f"Teachable Machine bridge running in {mode} mode.", flush=True)
    print(f"Open http://{args.host}:{args.port}/", flush=True)
    print("Press Control-C to stop.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping bridge...")
    finally:
        runner.close()
        server.server_close()


if __name__ == "__main__":
    main()
