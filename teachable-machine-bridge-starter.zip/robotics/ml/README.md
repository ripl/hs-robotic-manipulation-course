# Teachable Machine Bridge

This folder contains a small local bridge for the Teachable Machine robotics activity.

The browser runs the Teachable Machine image model. The Python server receives stable predictions and maps them to robot actions.

Start in dry-run mode:

```bash
python robotics/ml/teachable_machine_bridge.py
```

Open:

```text
http://127.0.0.1:8765/
```

Dry-run mode prints the action that would run. It does not move the robot.

Physical execution is disabled unless you explicitly pass:

```bash
python robotics/ml/teachable_machine_bridge.py --execute
```

Use `--execute` only after checking the action mapping, recording safe robot positions, and testing with the arm powered off or clear of obstacles.
